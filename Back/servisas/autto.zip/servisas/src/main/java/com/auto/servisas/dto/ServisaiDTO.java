package com.auto.servisas.dto;

import lombok.Data;

;

@Data
public class ServisaiDTO {

	private Long id;
	private String namePvd;
	private String nameAdr;
	private String nameDir;

}



