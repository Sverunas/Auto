package com.auto.servisas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServisasApplicationTests {

	@Test
	void contextLoads() {
	}

}
